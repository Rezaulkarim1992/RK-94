# Rk-
RK attack fot tool 
apt update
apt upgrade
apt install python
apt install python2
apt install git
pkg install requests mechanize
cd rk
ls
git clone https://github.com/Rezaulkarim1992/Rk-.git
gmail: rezaul
password: rezaul
